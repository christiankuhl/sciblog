'''
Functions specific to the multicurve Hull-White models
'''

from numpy import exp, sqrt
from ..utility.utility import BT


def params(T, a_d, a_f, s_d, s_f, rho):
    mu_x = -exp(-2 * a_d * T) * (exp(a_d * T) - 1)**2 * s_d**2 / (2 * a_d**2)
    mu_y = -rho * s_f * s_d / a_d * \
        ((1 - exp(-a_f * T)) / a_f + (exp(-(a_f + a_d) * T) - 1) / (a_d + a_f))
    s_x = s_d * sqrt((1 - exp(-2 * a_d * T)) / (2 * a_d))
    s_y = s_f * sqrt((1 - exp(-2 * a_f * T)) / (2 * a_f))
    rho_xy = rho * s_d * s_f / \
        ((a_f + a_d) * s_x * s_y) * (1 - exp(-(a_d + a_f) * T))
    return mu_x, mu_y, s_x, s_y, rho_xy


def VD(T, T_i, a_d, a_f, s_d, s_f, rho):
    return s_d**2 / a_d**2 * (T_i - T + 2 / a_d * exp(-a_d * (T_i - T))
                    - 1 / (2 * a_d) * exp(-2 * a_d * (T_i - T)) - 3 / (2 * a_d))


def Vf(T, T_i, a_d, a_f, s_d, s_f, rho):
    return s_d**2 / a_d**2 * (T_i - T + 2 / a_d * exp(-a_d * (T_i - T)) - 1 / (2 * a_d)
                              * exp(-2 * a_d * (T_i - T)) - 3 / (2 * a_d))\
        + s_f**2 / a_f**2 * (T_i - T + 2 / a_f * exp(-a_f * (T_i - T)) - 1 / (2 * a_f)
                             * exp(-2 * a_f * (T_i - T)) - 3 / (2 * a_f))\
        + rho * s_d * s_f / (a_d * a_f) * (T_i - T + (exp(-a_d * (T_i - T)) - 1) / a_d
                            + (exp(-a_f * (T_i - T)) - 1) / a_f + (exp(-(a_d + a_f) *
                                                        (T_i - T)) - 1) / (a_d + a_f))


def A(T, T_i, a_d, a_f, s_d, s_f, rho, curve):
    if curve.Type == "OISCurve":
        _V = VD
    else:
        _V = Vf
    value = curve(T_i) / curve(T) * exp(1 / 2 * (_V(T, T_i, a_d, a_f, s_d, s_f, rho)
                                                 - _V(0., T_i, a_d, a_f,
                                                      s_d, s_f, rho)
                                                 + _V(0, T, a_d, a_f, s_d, s_f, rho)))
    return value


def delta(u, swaption, a_d, a_f, s_d, s_f, rho):
    curve = swaption.OISCurve
    flt = swaption.FloatingLegTimes[1:]
    fix = swaption.FixedLegTimes[1:]
    T = swaption.Expiry
    mu_x, mu_y, s_x, s_y, rho_xy = params(T, a_d, a_f, s_d, s_f, rho)
    res = sum(A(T, T_i, a_d, a_f, s_d, s_f, rho, curve) * exp(-BT(T, T_i, a_d) *\
                                    (u * s_x * sqrt(2) + mu_x)) for T_i in flt)\
        + sum(swaption.ForwardRate * A(T, T_i, a_d, a_f, s_d, s_f, rho, curve) *
              exp(-BT(T, T_i, a_d) * (u * s_x * sqrt(2) + mu_x)) for T_i in fix)
    return res


def h1(u, y, T, a_d, a_f, s_d, s_f, rho):
    '''
    Reminder: j=i-1
    '''
    mu_x, mu_y, s_x, s_y, rho_xy = params(T, a_d, a_f, s_d, s_f, rho)
    res = (y - mu_y) / (s_y * sqrt(1 - rho_xy**2)) - \
        rho_xy * (u * sqrt(2)) / (sqrt(1 - rho_xy**2))
    return res


def h2(u, y, T, T_i, T_j, a_d, a_f, s_d, s_f, rho):
    mu_x, mu_y, s_x, s_y, rho_xy = params(T, a_d, a_f, s_d, s_f, rho)
    res1 = h1(u, y, T, a_d, a_f, s_d, s_f, rho)
    res = res1 + (BT(T, T_j, a_f) - BT(T, T_i, a_f)) * \
        s_y * sqrt(1 - rho_xy**2)
    return res


def lambdakappa(u, T, T_i, T_j, a_d, a_f, s_d, s_f, rho, oiscurve, forwardcurve):
    mu_x, mu_y, s_x, s_y, rho_xy = params(T, a_d, a_f, s_d, s_f, rho)
    l = A(T, T_i, a_d, a_f, s_d, s_f, rho, oiscurve) * exp(-BT(T, T_i, a_d) * \
                                    (u * s_x * sqrt(2) + mu_x)) * A(T, T_j, a_d,
                             a_f, s_d, s_f, rho, forwardcurve) / A(T, T_i, a_d,
                             a_f, s_d, s_f, rho, forwardcurve) * exp((-BT(T, T_j,
                            a_d) + BT(T, T_i, a_d)) * (u * s_x * sqrt(2) + mu_x))
    k = (-BT(T, T_j, a_f) + BT(T, T_i, a_f)) * (mu_y - 1 / 2 * (1 - rho_xy**2) *\
        s_y**2 * (BT(T, T_j, a_f) - BT(T, T_i, a_f)) + rho_xy * s_y * u * sqrt(2))
    return l * exp(k)


def q(u, y, T, T_i, T_j, a_d, a_f, s_d, s_f, rho):
    mu_x, mu_y, s_x, s_y, rho_xy = params(T, a_d, a_f, s_d, s_f, rho)
    return (BT(T, T_i, a_f) - BT(T, T_j, a_f)) * y + (BT(T, T_i, a_d) - \
                                BT(T, T_j, a_d)) * (u * s_x * sqrt(2) + mu_x)
