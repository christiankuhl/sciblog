'''
Utility functions shared throughout the module.
'''

import math
import numpy as np
import csv
from itertools import izip, tee


def printParameters(vars, calibrationset):
    print ", ".join(map(lambda p: "%s=%.10g" % (p[0], p[1]), vars.items()))
    if calibrationset.Product.__name__ == "Swaption":
        for s in calibrationset:
            print "Expiry=%d, Tenor=%d: BlackPrice=%f, ModelPrice=%f, RelErr=%.1f%%, AbsErr=%.2g"\
                % (s.Expiry, s.Tenor, s.BlackPrice, s.ModelPrice, 100 *
                   (s.ModelPrice / s.BlackPrice - 1), s.ModelPrice - s.BlackPrice)
    else:
        for s in calibrationset:
            print "Expiry=%f: BlackPrice=%f, ModelPrice=%f, RelErr=%.1f%%, AbsErr=%.2g"\
                % (s.Expiry, s.BlackPrice, s.ModelPrice, 100 *
                   (s.ModelPrice / s.BlackPrice - 1), s.ModelPrice - s.BlackPrice)


def pairwise(iterable):
    "s -> (s0,s1), (s1,s2), (s2, s3), ..."
    a, b = tee(iterable)
    next(b, None)
    return izip(a, b)


def Phi(x):
    '''cumulative distribution function of N(0,1)'''
    return .5 + .5 * math.erf(x / np.sqrt(2))


def BT(n, p, a):
    if not a == 0:
        res = (1 - np.exp(a * (n - p))) / a
    else:
        res = n - p
    return res


def RSS(iterable):
    return sum(x**2 for x in iterable)


def Norm1(iterable):
    return sum(abs(x) for x in iterable)


def Norm2(iterable):
    return np.sqrt(RSS(iterable))


def MaxNorm(iterable):
    return max(map(abs, iterable))
