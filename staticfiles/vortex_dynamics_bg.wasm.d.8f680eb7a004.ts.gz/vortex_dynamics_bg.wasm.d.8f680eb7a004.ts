/* tslint:disable */
/* eslint-disable */
export const memory: WebAssembly.Memory;
export function __wbg_nvortexproblem_free(a: number): void;
export function nvortexproblem_new(a: number, b: number, c: number, d: number): number;
export function nvortexproblem_mesh(a: number, b: number, c: number): void;
export function __wbindgen_malloc(a: number): number;
export function __wbindgen_free(a: number, b: number): void;
