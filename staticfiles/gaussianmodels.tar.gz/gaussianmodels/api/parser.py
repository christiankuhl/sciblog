'''
Defines the argument parser for a command line interface to the module.
'''

from argparse import ArgumentParser

parser = ArgumentParser(description='''Calibrate termstructure models to market data.
                        When called without any arguments, a calibration to example
                        data is executed.''')
parser.add_argument('-p', '--product', type=str,
                    help='The product to calibrate on. Values: "Caplet" or "Swaption"',
                                                                    default="Swaption")
parser.add_argument('-o', '--oiscurve', type=str,
                    help='The OIS curve to use.',
                    default="gaussianmodels/marketdata/exampledata/OISCurve.csv")
parser.add_argument('-f', '--fwdcurve', type=str,
                    help='The forward curve to use.',
                    default="gaussianmodels/marketdata/exampledata/ForwardCurve6m.csv")
parser.add_argument('-m', '--model', type=str,
                    help='The model to use. Values: "HW1F", "HW2F", "HJMGaussian"',
                                                                    default="HW1F")
parser.add_argument('-z0', type=float, nargs='+',
                    help='The parameter values to start with.',
                    default=[0.020454, 0.024395, 0.002508, 0.011345, -0.912525])
parser.add_argument('-n', '--now', type=str, default="2010/02/08")
parser.add_argument('-d', '--marketdata', type=str, help='Marketdata for the product.',
                    default="gaussianmodels/marketdata/exampledata/swaptions.csv")
parser.add_argument('-r', '--results', type=str, help='Output file (csv)',
                    default="../results.txt")
parser.add_argument('-t', '--target', type=str,
                    help='The target function to use. Values: "RSS", "Norm1", "Norm2", "MaxNorm"',
                    default="RSS")
parser.add_argument('--relative', action='store_true',
                    help='Use relative calibration errors')
parser.add_argument('-opt', '--optimizer', type=str,
                    help='The optimizer to use for scipy.optimize.minimize.',
                    default="Nelder-Mead")
