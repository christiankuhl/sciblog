#!/usr/bin/env python

from api.parser import parser
from marketdata.marketdata import Curve, CalibrationSet
from products.products import Swaption, Caplet
from models.models import SingleCurveHW2F, MultiCurveHW1F, HJMGaussian
from datetime import datetime
from utility.utility import Norm1, Norm2, RSS, MaxNorm

args = parser.parse_args()
print args

if args.product == "Swaption":
    product = Swaption
else:
    product = Caplet

marketdata_file = args.marketdata

if args.target in ["Norm1", "Norm2", "MaxNorm", "RSS"]:
    targetfunction = globals()[args.target]
else:
    targetfunction = RSS

now_date = datetime.strptime(args.now, "%Y/%m/%d")
forwardcurve = Curve(marketdata_file=args.fwdcurve,
                     now=now_date,
                     curve_type="ForwardCurve")
oiscurve = Curve(marketdata_file=args.oiscurve,
                 now=now_date,
                 curve_type="OISCurve")

multicurve = True
if args.model == "HW1F":
    model = MultiCurveHW1F
elif args.model == "HW2F":
    model = SingleCurveHW2F
    multicurve = False
else:
    model = HJMGaussian

if multicurve:
    calibrationset = CalibrationSet(model=model,
                                    product=product,
                                    product_data=marketdata_file,
                                    curves=[oiscurve, forwardcurve],
                                    targetfunction=targetfunction,
                                    relative_errors=args.relative,
                                    optimizer=args.optimizer)
else:
    calibrationset = CalibrationSet(model=model,
                                    product=product,
                                    product_data=marketdata_file,
                                    curves=forwardcurve,
                                    targetfunction=targetfunction,
                                    relative_errors=args.relative,
                                    optimizer=args.optimizer)

results, error = calibrationset.Calibrate(start=args.z0)

result_string = ", ".join(map(lambda s: s + " = %.10g", ["Error"] +
                              calibrationset.Model.ParameterNames)) % ((error,)
                                                            + tuple(results))
print result_string

with open(args.results, "wb") as file:
    file.write(str(args))
    file.write(result_string + "\n")
    for s in calibrationset:
        file.write(str(s) + "\n")
