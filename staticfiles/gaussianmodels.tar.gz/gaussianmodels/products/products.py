'''
Definition of product classes.
'''

from ..marketdata.marketdata import MarketDataAPI, Curve
from ..utility.utility import Phi, pairwise
from numpy import sqrt
from math import log


class Product(object):
    '''
    Base class for financial products.
    '''
    ReprParams = [("Notional", "%f"), ("ForwardRate", "%f%%"),
                  ("BlackPrice", "%f"), ("ModelPrice", "%f")]

    def __init__(self, expiry, volatility, notional):
        self.Expiry = expiry
        self.Volatility = volatility
        self.Notional = notional
        self.ModelPrice = 0.

    def __str__(self):
        param_list = self.ReprParams + Product.ReprParams
        param_list_str = map(": ".join, param_list)
        fmt_string = self.__class__.__name__ + \
            ": {" + ", ".join(param_list_str) + "}"
        param_tuple = tuple([getattr(self, name) if name != "ForwardRate" else
                             100 * self.ForwardRate for (name, _) in param_list])
        product_str = fmt_string % param_tuple
        return product_str

    def __repr__(self):
        return self.__str__()

    @classmethod
    def FromFile(cls, file_name):
        raw_data = MarketDataAPI(file_name)
        # transform original keys with .lower() for dynamic calling
        data = [dict((key.lower(), value) for (key, value) in row.items())
                for row in raw_data]
        print cls
        print data
        products = [cls(**row) for row in data]
        return products


class Swaption(Product):
    '''
    Swaption(expiry=n,tenor=p,volatility=sigma) represents a European swaption
    expiring n years from now and swap tenor p years, valued with (market)
    volatility sigma.
    '''
    ReprParams = [("Expiry", "%dy"), ("Tenor", "%dy"), ("Volatility", "%f")]

    def __init__(self, expiry, tenor, volatility, notional=100):
        super(Swaption, self).__init__(expiry, volatility, notional)
        self.Tenor = tenor
        self.FixedLegTimes = map(
            lambda x: self.Expiry + x, range(self.Tenor + 1))
        self.FloatingLegTimes = map(
            lambda x: self.Expiry + .5 * x, range(2 * self.Tenor + 1))
        if not self.MultiCurve:
            self.ForwardRate = -(self.ForwardCurve(self.Expiry + self.Tenor) - \
                                 self.ForwardCurve(self.Expiry))\
                / (self.ForwardCurve.summed(self.Expiry + self.Tenor) - \
                                        self.ForwardCurve.summed(self.Expiry))
        else:
            self.ForwardRate = sum(self.OISCurve(T_i) * (self.ForwardCurve(T_j) /
                                                         self.ForwardCurve(T_i) - 1)
                                   for (T_j, T_i) in pairwise(self.FloatingLegTimes))\
                                   / (self.OISCurve.summed(self.Expiry + self.Tenor)
                                            - self.OISCurve.summed(self.Expiry))
        self.BlackPrice = self.ComputeBlackPrice()

    def ComputeBlackPrice(self):
        df = self.OISCurve(self.Expiry)
        d1 = 0.5 * self.Volatility * sqrt(self.Expiry)
        price = self.Notional * \
            (1 - (1 + self.ForwardRate)**(-self.Tenor)) * df * (2 * Phi(d1) - 1)
        return price


class Caplet(Product):
    delta = 0.25
    ReprParams = [("Expiry", "%dy"), ("Volatility", "%f")]

    def __init__(self, expiry, forwardrate, volatility, strike, notional=100):
        super(Caplet, self).__init__(expiry, volatility, notional)
        self.Strike = strike
        self.ForwardRate = forwardrate
        self.BlackPrice = self.ComputeBlackPrice()

    def ComputeBlackPrice(self):
        d1 = (log(self.ForwardRate / self.Strike) + (self.Volatility**2)
              * self.Expiry / 2) / (self.Volatility * sqrt(self.Expiry))
        d2 = d1 - self.Volatility * sqrt(self.Expiry)
        price = self.Notional * (self.ForwardRate * self.delta * (Phi(d1) - Phi(d2))
                                 * self.OISCurve(self.Expiry))
        return price
