'''
Functions specific to the singlecurve Hull-White models
'''

import numpy as np
from ..utility.utility import BT


def A(n, p, a, b, sx, sy, rho, curve):
    '''
    Returns A as in Brigo/Mercurio
    '''
    return curve(p) / curve(n) * np.exp(1 / 2 * (Volatility(n, p, 1, sx, sy, a, b, rho)
                                                 - Volatility(0, p, 1, sx, sy, a, b, rho)
                                                 + Volatility(0, n, 1, sx, sy, a, b, rho)))


def lambdakappa(u, n, p, a, b, sx, sy, rho, B):
    '''
    Essential part of the integrand for the theoretical swaption prices
    '''
    mu_x, mu_y, eta_x, eta_y, eta_xy = params(n, a, b, sx, sy, rho)
    lambda1 = A(n, p, a, b, sx, sy, rho, B) * \
        np.exp(-BT(n, p, a) * (eta_x * np.sqrt(2) * u + mu_x))
    kappa = -BT(n, p, b) * (mu_y - 1 / 2 * (1 - eta_xy**2) * eta_y**2
                            * BT(n, p, b) + eta_xy * eta_y * np.sqrt(2) * u)
    return lambda1 * np.exp(kappa)


def params(n, a, b, sx, sy, rho):
    '''
    Returns the parameters mu_*, eta_* as in Brigo/Mercurio
    '''
    mu_x = (sx**2 / a**2 + rho * sx * sy / (a * b)) * (1 - np.exp(-a * n)) + \
            sx**2 / (2 * a**2) * (np.exp(-a * n) - np.exp(-2 * a * n)) + rho * sx\
            * sy / (b * (a + b)) * (np.exp(-b * n) - np.exp(-(a + b) * n))
    mu_y = (sy**2 / b**2 + rho * sx * sy / (a * b)) * (1 - np.exp(-b * n)) +\
            sy**2 / (2 * b**2) * (np.exp(-b * n) - np.exp(-2 * b * n)) + rho *\
            sx * sy / (a * (a + b)) * (np.exp(-a * n) - np.exp(-(a + b) * n))
    eta_x = sx * np.sqrt((1 - np.exp(-2 * a * n)) / (2 * a))
    eta_y = sy * np.sqrt((1 - np.exp(-2 * b * n)) / (2 * b))
    eta_xy = rho * sx * sy / ((a + b) * eta_x * eta_y) * \
        (1 - np.exp(-(a + b) * n))
    return mu_x, mu_y, eta_x, eta_y, eta_xy


def h(y, u, n, p, a, b, sx, sy, rho):
    '''
    Return helper functions h1 and h2 (cf. Brigo/Mercurio)
    '''
    _, mu_y, _, eta_y, eta_xy = params(n, a, b, sx, sy, rho)
    h1 = (y - mu_y) / (eta_y * np.sqrt(1 - eta_xy**2)) - \
        np.sqrt(2) * eta_xy * u / np.sqrt(1 - eta_xy**2)
    h2 = h1 + BT(n, p, b) * eta_y * np.sqrt(1 - eta_xy**2)
    return (h1, h2)


def Volatility(n, k, delta, sx, sy, a, b, rho):
    '''
    Swaption volatility expressed as a function of the fit parameters
    '''
    res = sx**2 / (a**2) * (delta * (k - n) + 2 / a * np.exp(-a * delta * (k - n))\
                    - 1 / (2 * a) * np.exp(-2 * a * delta * (k - n)) - 3 / (2 * a)) \
        + sy**2 / (b**2) * (delta * (k - n) + 2 / b * np.exp(-b * delta * (k - n))\
                    - 1 / (2 * b) * np.exp(-2 * b * delta * (k - n)) - 3 / (2 * b)) \
        + (2 * rho * sx * sy) / (a * b) * (delta * (k - n) + (np.exp(-a * delta * \
                    (k - n)) - 1) / a + (np.exp(-b * delta * (k - n)) - 1) / b -\
                    (np.exp(-(a + b) * delta * (k - n)) - 1) / (a + b))
    if n == k == 0:
        return 0
    return np.sqrt(res)


def CapletVolatility(n, delta, sx, sy, a, b, rho):
    '''
    Volatility expressed as a function of the fit parameters
    '''
    res = sx**2 / (2.0 * a**3) * (1.0 - np.exp(-a * delta))**2 * (1.0 - np.exp(-2.0 * a * n)) \
        + sy**2 / (2.0 * b**3) * (1.0 - np.exp(-b * delta))**2 * (1.0 - np.exp(-2.0 * b * n)) \
        + (2.0 * rho * sx * sy) / ((a * b) * (a + b)) * (1.0 - np.exp(-a * delta)
                                ) * (1.0 - np.exp(-b * delta)) * (1.0 - (np.exp(-(a + b) * n)))
    return np.sqrt(abs(res))
