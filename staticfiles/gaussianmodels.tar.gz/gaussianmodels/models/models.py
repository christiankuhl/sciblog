'''
Definition of model classes as well as the generic 'Model' parent class.
'''

from math import pi
from numpy import exp, log, sqrt, sign
from numpy.polynomial.hermite import hermgauss
from scipy.optimize import minimize, fsolve
from ..utility.utility import Phi, BT, pairwise
import singlecurve as sc
import multicurve as mc
import hjmgaussian as hjm
from ..products.products import Caplet


class Model(object):
    '''
    Base class for concrete interest rate models.
    '''

    def __init__(self, product, optimizer):
        self.Optimizer = optimizer
        if product.__name__ == "Swaption":
            self.Price = self.SwaptionPrice
        else:
            self.Price = self.CapletPrice

    def Calibrate(self, calibrationset, start):
        "Calibrate 'self'. Delegates calibration details to 'calibrationset'"
        sol = minimize(lambda z: calibrationset.ErrorMeasure(*z), start,
                       method=self.Optimizer, bounds=self.ParameterBounds)
        return sol.x, sol.fun


class HJMGaussian(Model):
    '''
    Represents a multicurve HJM Gaussian model.
    '''
    ParameterNames = ["b_d", "b_s", "s_d", "s_s"]
    ParameterBounds = ((-2.0, 2.0), (-2.0, 2.0), (-2.0, 2.0), (-2.0, 2.0))

    @staticmethod
    def SwaptionPrice(swaption, b_d, b_s, s_d, s_s, notional=100.):
        xH, wH = hermgauss(20)
        T = swaption.Expiry
        fwd = swaption.ForwardCurve
        ois = swaption.OISCurve
        yy = []
        Gamma1 = sqrt((-1 + exp(2 * b_d * T)) * s_d**2) / (2 * b_d**3)
        Gamma2 = ((-1 + exp(2 * b_s * T)) * s_s**2) / (2 * b_s**3)
        for x in xH:
            # Build the implicit equation r(y)==0
            def r(y):
                return sum(exp(hjm.BigATilde(T, T_i, T_k, b_d, b_s, s_d, s_s,
                    ois, fwd) + hjm.BigBTilde1(T, T_i, T_k, b_d, b_s, s_d, s_s)
                    * x * sqrt(2 * Gamma1) + hjm.BigBTilde2(T_i, T_k, b_d, b_s,
                    s_d, s_s) * y) - 1 for (T_i, T_k) in pairwise(
                                                    swaption.FloatingLegTimes))\
                    - swaption.ForwardRate * sum(exp(hjm.a(T, T_k, b_d, b_s, s_d,
                        s_s, ois) + hjm.BT(T, T_k, b_d) * x * sqrt(2 * Gamma1))
                          for T_k in swaption.FixedLegTimes[1:])
            sol = fsolve(r, 0, fprime=lambda y: sum(hjm.BigBTilde2(T_i, T_k, b_d,
                                                                   b_s, s_d, s_s)
                            * exp(hjm.BigATilde(T, T_i, T_k, b_d, b_s, s_d, s_s,
                            ois, fwd) + hjm.BigBTilde1(T, T_i, T_k, b_d, b_s, s_d, s_s)\
                             * x * sqrt(2 * Gamma1) + hjm.BigBTilde2(T_i, T_k, b_d, b_s,
                                                                    s_d, s_s) * y) - 1
                            for (T_i, T_k) in pairwise(swaption.FloatingLegTimes)))
            yy.append(sol)
        # Patch together integrand at the abscissas
        integral = -notional * ois(T) * sqrt(2 * Gamma1 / pi) * sum(w * (sum(
            exp(hjm.BigATilde(T, T_i, T_k, b_d, b_s, s_d, s_s, ois, fwd) +\
            hjm.BigBTilde1(T, T_i, T_k, b_d, b_s, s_d, s_s) * x * sqrt(2 * Gamma1)) *
            exp(.5 * Gamma2 * hjm.BigBTilde2(T_i, T_k, b_d, b_s, s_d, s_s)**2)
            * Phi((-hjm.BigBTilde2(T_i, T_k, b_d, b_s, s_d, s_s) * Gamma2 - y)\
                  / sqrt(Gamma2)) - Phi(-y / sqrt(Gamma2))
                        for (T_i, T_k) in pairwise(swaption.FloatingLegTimes))
            - swaption.ForwardRate * sum(
                exp(hjm.BigATilde(T, T_i, T_k, b_d, b_s, s_d, s_s, ois, fwd) +
                hjm.BigBTilde1(T, T_i, T_k, b_d, b_s, s_d, s_s) * x * \
                sqrt(2 * Gamma1)) * Phi(-y / sqrt(Gamma2))
                        for (T_i, T_k) in pairwise(swaption.FixedLegTimes)))
                                            for (x, y, w) in zip(xH, yy, wH))
        swaption.ModelPrice = integral
        return integral

    def CapletPrice(self, caplet, b_d, b_s, s_d, s_s):
        zeta = -((exp(-2 * b_d * caplet.Expiry) - 1) * s_d**2 * (1 - exp(-b_d *
                                        caplet.delta))**2) / (2 * (b_d)**3) \
               - ((exp(-2 * b_s * caplet.Expiry) - 1) * s_s**2 *
                  (1 - exp(-b_s * caplet.delta))**2) / (2 * (b_s)**3)
        df1 = caplet.OISCurve(caplet.Expiry)
        df = caplet.OISCurve(caplet.Expiry + caplet.delta)
        xi = log(df1 / df) - 0.5 * zeta
        adj_strike = (1 + caplet.delta * caplet.Strike) * exp(-zeta)
        price = df * exp(xi) * (exp(zeta / 2) * Phi(1 / (sqrt(zeta)) * \
                                            (log(1 / adj_strike) + zeta))) \
            - df * exp(xi) * (adj_strike *
                              Phi(1 / (sqrt(zeta)) * log(1 / adj_strike)))
        caplet.ModelPrice = price
        return price


class SingleCurveHW2F(Model):
    '''
    Represents a singlecurve two-factor Hull-White Model
    '''
    ParameterNames = ["a", "b", "sx", "sy", "rho"]
    ParameterBounds = ((-2.0, 2.0), (-2.0, 2.0),
                       (0.001, 1.0), (0.001, 1.0), (-1.0, 1.0))

    @staticmethod
    def SwaptionPrice(swaption, a, b, sx, sy, rho, notional=100.):
        n = swaption.Expiry
        p = swaption.Tenor
        # For the single curve model, both the ois and the forward curve are
        # identical and are distinguished here only for illustrative purposes
        fwd = swaption.ForwardCurve
        ois = swaption.OISCurve
        xH, wH = hermgauss(20)
        mu_x, _, eta_x, eta_y, eta_xy = sc.params(
            swaption.Expiry, a, b, sx, sy, rho)
        sfwd = swaption.ForwardRate
        c = [sfwd for i in range(swaption.Tenor - 1)]
        c.append(sfwd + 1)
        # Compute solution of the implicit equation in Brigo/Mercurio 2006 for each
        # Gauss-Hermite abscissa, collect results in y
        y = []
        for x in xH:
            # Build the implicit equation r(yy)==0
            v = [ci * sc.A(n, i + n, a, b, sx, sy, rho, fwd) * exp(-BT(n, i + n, a)
                                                * (sqrt(2) * eta_x * x + mu_x))
                                                for (i, ci) in enumerate(c, start=1)]
            # Equation is:
            equation = " + ".join(["%f*Exp[%f*y]" % (vi, Bi) for (vi, Bi) in zip(
                v, [-BT(n, i + n, b) for (i, _) in enumerate(v, start=1)])]) + " == 1"
            def r(yy):
                return sum((vi * exp(-BT(n, i + n + 1, b) * yy)) for (i, vi)
                                                        in enumerate(v)) - 1.0
            scan = map(lambda k: (k, sign(r(k))), range(-11, 11))
            for j in range(len(scan) - 1):
                if scan[j][1] != scan[j + 1][1]:
                    y0 = scan[j][0] + 0.5
                    break
                else:
                    y0 = None
            if y0 is not None:
                # Scan detected sign change, try Newton
                try:
                    sol = fsolve(r, y0, fprime=lambda yy: sum((-BT(n, i + n, b)
                                        * vi * exp(-BT(n, i + n, b) * yy))
                                        for (i, vi) in enumerate(v, start=1)))
                except:
                    pass
            else:
                # No sign change detected, try to get out of here with "constant continuation",
                # i.e. appending the old solution
                pass
            try:
                y.append(sol)
            except:
                # Lasciate ogni speranza, voi ch'entrate!
                pass
        # Patch together integrand at the abscissas
        g1 = [sc.h(yi, xi, n, p, a, b, sx, sy, rho) for (xi, yi) in zip(xH, y)]
        g1 = map(lambda u: (Phi(-u[0]), Phi(-u[1])), g1)
        g2 = [sum(ci * sc.lambdakappa(u, n, i + n + 1, a, b, sx, sy, rho, fwd)
                  for (i, ci) in enumerate(c)) for u in xH]
        integrand = [w * (k1 - k2 * g)
                     for (x, w, (k1, k2), g) in zip(xH, wH, g1, g2)]
        # Integrate
        integral = notional * fwd(n) / sqrt(pi) * sum(integrand)
        swaption.ModelPrice = integral
        return integral

    def CapletPrice(self, caplet, a, b, sx, sy, rho):
        sigma = sc.CapletVolatility(
            caplet.Expiry, caplet.delta, sx, sy, a, b, rho)
        c = Caplet(caplet.Expiry, caplet.ForwardRate, volatility=sigma,
                   strike=caplet.Strike, notional=caplet.Notional)
        price = c.BlackPrice
        caplet.ModelPrice = price
        return price


class MultiCurveHW1F(Model):
    '''
    Represents a multicurve one-factor Hull-White Model
    '''
    ParameterNames = ["a_d", "a_f", "s_d", "s_f", "rho"]
    ParameterBounds = ((-2.0, 2.0), (-2.0, 2.0),
                       (0.001, 1.0), (0.001, 1.0), (-1.0, 1.0))

    @staticmethod
    def SwaptionPrice(swaption, a_d, a_f, s_d, s_f, rho, notional=100.):
        xH, wH = hermgauss(20)
        T = swaption.Expiry
        fwd = swaption.ForwardCurve
        ois = swaption.OISCurve
        # Compute solution of the implicit equation in Brigo/Mercurio 2006 for
        # each Gauss-Hermite abscissa, collect results in y
        yy = []
        for x in xH:
            # Build the implicit equation r(y)==0
            def r(y):
                return sum(mc.A(T, T_i, a_d, a_f, s_d, s_f, rho, ois)
                           * exp(-BT(T, T_i, a_d) * x)
                           * (mc.A(T, T_j, a_d, a_f, s_d, s_f, rho, fwd)
                              / mc.A(T, T_i, a_d, a_f, s_d, s_f, rho, fwd)
                              * exp(mc.q(x, y, T, T_i, T_j, a_d, a_f, s_d, s_f,
                                         rho)) - 1) for (T_j, T_i) in
                                         pairwise(swaption.FloatingLegTimes))\
                    - sum(swaption.ForwardRate * exp(-BT(T, T_i, a_d) * x)
                          * mc.A(T, T_i, a_d, a_f, s_d, s_f, rho, ois)
                          for T_i in swaption.FixedLegTimes[1:])
            sol = fsolve(r, 0)
            yy.append(sol)
        # Patch together integrand at the abscissas
        integral = notional * ois(T) / sqrt(pi)\
            * sum(w * (mc.delta(x, swaption, a_d, a_f, s_d, s_f, rho) * Phi(
                mc.h1(x, y, T, a_d, a_f, s_d, s_f, rho)) - sum(mc.lambdakappa(x,
                                T, T_i, T_j, a_d, a_f, s_d, s_f, rho, ois, fwd)
                        * Phi(mc.h2(x, y, T, T_i, T_j, a_d, a_f, s_d, s_f, rho))
                        for (T_j, T_i) in pairwise(swaption.FloatingLegTimes)))
                                            for (x, y, w) in zip(xH, yy, wH))
        swaption.ModelPrice = integral
        return integral
