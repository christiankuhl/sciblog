'''
Specific functions for the HJMGaussian model.
'''

from numpy import exp, sqrt, log


def BT(t, s, b):
    return exp(-b * s) - exp(-b * t)


def a(T, T_k, b_d, b_s, s_d, s_s, oiscurve):
    value = log(oiscurve(T_k) / oiscurve(T)) + s_d**2 / (4 * b_d**3) *\
        (exp(-2 * b_d * T) * (4 * exp(b_d * T) - 1 + exp(2 * b_d * T) * (2 * b_d
        * T - 3)) - exp(-2 * b_d * T_k) * (4 * exp(b_d * T_k) - 1 - 4 * exp(b_d *
        (T + T_k)) + exp(2 * b_d * T) + 2 * b_d * T * exp(2 * b_d * T_k))
        - 2 * (exp(-2 * b_d * (T_k + 2 * T)) * (exp(b_d * T) - exp(b_d * T_k))
                                                    * (exp(b_d * T) - 1)**2))
    return value


def atilde(T, T_i, T_k, b_d, b_s, s_d, s_s, fwdcurve):
    value = log(fwdcurve(T_i) / fwdcurve(T_k)) + (s_d**2 / (2 * b_d**3)) *\
    ((exp(2 * b_d * T) - 1) * (exp(b_d * T) - exp(b_d * T_k)) * (exp(b_d * T_k)
                        - exp(b_d * T_i)) * (exp(-b_d * (T + 2 * T_k + T_i))))\
        - 0.25 * (((s_d**2 / b_d**3) * (exp(2 * b_d * T) - 1) * exp(-2 * b_d *
                            (T_k + T_i)) * (exp(b_d * T_k) - exp(b_d * T_i))**2)
                            + (s_s**2 / b_s**3) * (exp(2 * b_s * T) - 1)
                            * exp(-2 * b_s * (T_k + T_i)) * (exp(b_s * T_k)
                                                        - exp(b_s * T_i))**2)
    return value


def BigATilde(T, T_i, T_k, b_d, b_s, s_d, s_s, ois, fwd):
    return a(T, T_k, b_d, b_s, s_d, s_s, ois) + atilde(T, T_i, T_k, b_d, b_s, s_d, s_s, fwd)


def BigBTilde1(T, T_i, T_k, b_d, b_s, s_d, s_s):
    return BT(T, T_k, b_d) + BT(T_i, T_k, b_d)


def BigBTilde2(T_i, T_k, b_d, b_s, s_d, s_s):
    return BT(T_i, T_k, b_s)
