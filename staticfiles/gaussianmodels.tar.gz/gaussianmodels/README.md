# gaussianmodels
This is a Python package intended to facilitate implementation, testing and
calibration of various market models to market data.
