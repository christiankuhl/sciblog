'''
Defines market data curves as well as interfaces for loading market data.
'''

import csv
from datetime import datetime, timedelta, date
from collections import OrderedDict
from ..utility.utility import pairwise, RSS, printParameters


class Curve(object):
    '''
    Base class for market data curves. __init__ takes a two-column csv file
    with header Date;Value and separator ';' as input. The parameter 'now'
    specifies the origin of the curve, now_value the corresponding curve value.
    If left out, 'now' is assumed to be the smallest date in the csv file and
    now_value is set accordingly.
    '''

    def __init__(self, marketdata_file, now=None, now_value=1., curve_type="OISCurve"):
        '''
        Create curve from csv 'marketdata_file' with header line 'Date;Value',
        where Date is formatted as %Y/%m%d.
        '''
        self.Type = curve_type
        self.__coreCurve__ = self.__loadCurveData__(marketdata_file)
        if now is not None:
            self.Origin = now
            self.__coreCurve__[now] = now_value
            self.__coreCurve__ = OrderedDict(sorted(
                self.__coreCurve__.items(), key=lambda t: t[0]))
        else:
            self.Origin = self.__coreCurve__.keys()[0]
        self.__interpolatedCurve__ = self.__interpolate__()
        self.SupportPoints = self.__coreCurve__.keys()
        self.Last = self.SupportPoints[-1]

    def __call__(self, t):
        "Get the curve value yearfraction t from now, using naive daycount"
        days = round(t * 365.25)
        eval_date = self.Origin + timedelta(days=days)
        if eval_date < self.Origin:
            value = 0
        elif eval_date > self.Last:
            value = self.__coreCurve__[self.Last]
        else:
            value = self.__interpolatedCurve__[eval_date]
        return value

    def __interpolate__(self):
        "Interpolate linearly between quoted data points"
        interpolatedcurve = OrderedDict()
        for (datefrom, dateto) in pairwise(self.__coreCurve__.keys()):
            startvalue = self.__coreCurve__[datefrom]
            endvalue = self.__coreCurve__[dateto]
            delta = (dateto - datefrom).days
            for k in range(delta):
                day = datefrom + timedelta(days=k)
                value = k / float(delta) * endvalue + \
                    (1 - k / float(delta)) * startvalue
                interpolatedcurve[day] = value
        interpolatedcurve[dateto] = endvalue
        return interpolatedcurve

    def __loadCurveData__(self, marketdata_file):
        raw_data = MarketDataAPI(marketdata_file)
        values = dict((row["Date"], row["Value"]) for row in raw_data)
        return OrderedDict(sorted(values.items(), key=lambda t: t[0]))

    def __str__(self):
        return str(self.__coreCurve__)

    def summed(self, index):
        return sum(self(i) for i in range(1, int(index) + 1))


class CalibrationSet(object):
    '''
    A CalibrationSet(model,product,marketdata) object represents a set of
    derivatives of type 'product' corresponding to the market data given in
    the file 'marketdata', on which to calibrate 'model'
    '''

    def __init__(self, model, product, product_data, curves, targetfunction=RSS,
                 relative_errors=False, optimizer="Nelder-Mead"):
        self.Product = product
        self.Model = model(product, optimizer)
        self.TargetFunction = targetfunction
        self.RelativeErrors = relative_errors
        if model.__name__ == "SingleCurveHW2F":
            self.Product.MultiCurve = False
            self.Product.OISCurve = curves
            self.Product.ForwardCurve = curves
        else:
            self.Product.MultiCurve = True
            self.Product.OISCurve = curves[0]
            self.Product.ForwardCurve = curves[1]
        self.Products = self.Product.FromFile(product_data)

    def __getitem__(self, index):
        return self.Products[index]

    def Calibrate(self, start):
        '''
        Calibrate to product data, starting the iteration at 'start'
        Actual calibration is delegated to self.Model.
        '''
        parameters, error = self.Model.Calibrate(self, start)
        return parameters, error

    def ErrorMeasure(self, *args, **kwargs):
        x = [self.Model.Price(p, *args, **kwargs) -
             p.BlackPrice for p in self.Products]
        if self.RelativeErrors:
            x = [q / p.BlackPrice for (p, q) in zip(self.Products, x)]
        res = self.TargetFunction(x)
        printParameters(OrderedDict(
            [("Error", res)] + zip(self.Model.ParameterNames, args)), self)
        return res


def MarketDataAPI(file):
    '''
    Generic market data API. Reads market data from a csv file with header line
    and separator ';', For curves, the header is expected to be 'Date; Value'
    with date formatted as %Y/%m%d, while it is 'Expiry;Tenor;Volatility' for
    swaptions and 'Expiry;Volatility;ForwardRate' for caplets.
    '''
    csv.register_dialect("mine", delimiter=";")
    parameter_types = {'Expiry': float, 'Tenor': int, 'Volatility': float,
                       'ForwardRate': float, 'Strike': float, 'Date':
                       lambda s: datetime.strptime(s, "%Y/%m/%d"), 'Value': float}
    rows = []
    with open(file, 'rb') as f:
        reader = csv.DictReader(f, dialect="mine")
        keys = reader.fieldnames
        for row in reader:
            for key in keys:
                row[key] = parameter_types[key](row[key])
            rows.append(row)
    return rows
