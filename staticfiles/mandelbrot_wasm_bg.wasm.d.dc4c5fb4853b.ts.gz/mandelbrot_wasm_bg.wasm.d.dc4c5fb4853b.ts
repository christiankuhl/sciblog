/* tslint:disable */
/* eslint-disable */
export const memory: WebAssembly.Memory;
export function __wbg_point_free(a: number): void;
export function point_new(a: number, b: number): number;
export function __wbg_applicationsettings_free(a: number): void;
export function __wbg_application_free(a: number): void;
export function application_height(a: number): number;
export function application_width(a: number): number;
export function application_new(): number;
export function application_update(a: number): void;
export function application_reset(a: number): void;
export function application_zoom(a: number, b: number, c: number): void;
export function application_shift(a: number, b: number): void;
export function application_image_buffer(a: number): number;
